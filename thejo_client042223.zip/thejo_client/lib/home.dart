import 'dart:convert';
import 'dart:io';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:syncfusion_flutter_charts/sparkcharts.dart';

class _SalesData {
  _SalesData(this.year, this.sales);

  final String year;
  final double sales;
}
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Color> gradientColors = [
    Color(0xFF50E4FF),
    Color(0xFF2196F3),
  ];

  double x=1;

  List<FlSpot> data = [

  ];

  bool showAvg = false;

  final client = MqttServerClient('mqtt-dashboard.com', '');

  double temp=0.0;
  double angleDiff=0.0;
  double vibration=0.0;
  double bladeLife=0.0;
  double rotation = 0.0;

  List<_SalesData> data1 = [
    _SalesData('Jan', 35),
    _SalesData('Feb', 28),
    _SalesData('Mar', 34),
    _SalesData('Apr', 32),
    _SalesData('May', 40)
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initMQTT();
  }

  void initMQTT()
  async {
    client.onDisconnected = onDisconnected;
    client.onConnected = onConnected;
    client.onSubscribed = onSubscribed;
    final connMess = MqttConnectMessage()
        .withClientIdentifier('Mqtt_MyClientUniqueId')
        .withWillTopic('willtopic') // If you set this you must set a will message
        .withWillMessage('My Will message')
        .startClean() // Non persistent session for testing
        .withWillQos(MqttQos.atLeastOnce);
    print('EXAMPLE::Mosquitto client connecting....');
    client.connectionMessage = connMess;

    try {
      await client.connect();
    } on NoConnectionException catch (e) {
      // Raised by the client when connection fails.
      print('EXAMPLE::client exception - $e');
      client.disconnect();
    } on SocketException catch (e) {
      // Raised by the socket layer
      print('EXAMPLE::socket exception - $e');
      client.disconnect();
    }

    client.subscribe("t4l", MqttQos.atMostOnce);
  }

  @override
  Widget build(BuildContext context) {

    client.updates!.listen((List<MqttReceivedMessage<MqttMessage?>>? c) {
      final recMess = c![0].payload as MqttPublishMessage;
      final pt =
      MqttPublishPayload.bytesToStringAsString(recMess.payload.message);


      print(
          'EXAMPLE::Change notification:: topic is <${c[0].topic}>, payload is <-- $pt -->');
      print('');

      Map<String, dynamic> data = json.decode(pt);

      setState(() {
        temp=data['temp'];
        angleDiff=data['angleDiff'];
        // rotation=data["angleDiff"];
        vibration=data['vibration'];



        String inString = temp.toStringAsFixed(2);
        temp=double.parse(inString);

        String inString1 = angleDiff.toStringAsFixed(2);
        angleDiff=double.parse(inString1);

        String inString2 = vibration.toStringAsFixed(2);
        vibration=double.parse(inString2);


        if (angleDiff < 0) {
          // The number is negative, so we'll convert it to positive
          angleDiff = angleDiff.abs();
          rotation=angleDiff/10;

        }

        if(angleDiff<6)
          {
            bladeLife=100;
          }

        else if(angleDiff<10 && angleDiff>7)
        {
          bladeLife=91;
        }
        else if(angleDiff<15 && angleDiff>11)
        {
          bladeLife=74;
        }
        else if(angleDiff<20 && angleDiff>16)
        {
          bladeLife=58;
        }
        else if(angleDiff<25 && angleDiff>21)
        {
          bladeLife=42;
        }
        else if(angleDiff<30 && angleDiff>26)
        {
          bladeLife=29;
        }
        else if(angleDiff<35 && angleDiff>31)
        {
          bladeLife=18;
        }
        else if(angleDiff<40 && angleDiff>36)
        {
          bladeLife=10;
        }
        else if(angleDiff<45 && angleDiff>41)
        {
          bladeLife=4;
        }
        else if(angleDiff>45){
          bladeLife=-1;
        }
        else
          {
            bladeLife=0;
          }


      });

      this.data.add(FlSpot(x,vibration));
      x=x+1;

    });

    return Scaffold(
      appBar: new AppBar(
        leadingWidth: 20, // <-- Use this
        centerTitle: false,
        iconTheme: IconThemeData(
            color: Colors.white
        ),
        title: const Text('Home', style: TextStyle(
            color: Colors.white
        )),
      ),

      body: Container(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(

            // mainAxisAlignment: MainAxisAlignment.start,
            // crossAxisAlignment: CrossAxisAlignment.start,
            children: [
          // SizedBox(
          // width: 400,
          // child: Card(
          // child: Padding(
          //   padding:EdgeInsets.all(10),
          //     child:Column(
          //       children: [
          //         Transform.rotate(
          //         angle: rotation,
          //         child: Image.asset(
          //           'assets/images/angle.png', // Replace with the path to your image asset
          //           width: 200,
          //           height: 200,
          //         ),
          //       ),
          //         Text("Blade Position",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20))
          //   ]
          //     ),),),),
              SizedBox(
                width: 400,
                child: Card(
                    child: Padding(
                      padding: EdgeInsets.all(10),
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [


                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Row(
                                      children: [
                                        Icon(Icons.favorite,color: Colors.green,),
                                        SizedBox(width: 10,),
                                        Text(
                                        'Blade Life',
                                        style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
                                      ),
                              ]
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      bladeLife<0?'Blade is Unstable':
                                      '$bladeLife %',
                                      style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
                                    ),
                                  ),
                                ),
                              ],
                            ),

                        SizedBox(height: 10,),
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Row(
                                      children: [
                                        Icon(Icons.bar_chart,color: Colors.orange,),
                                        SizedBox(width: 10,),
                                        Text(
                                        'Current Vibration',
                                        style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
                                      ),
                              ]
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      '$vibration',
                                      style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
                                    ),
                                  ),
                                ),
                              ],
                            ),

                        SizedBox(height: 10,),
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Row(
                                      children: [
                                        Icon(Icons.thermostat,color: Colors.red,),
                                        SizedBox(width: 10,),
                                        Text(
                                        'Temperature',
                                        style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
                                      ),
                              ]
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      '$tempº C',
                                      style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
                                    ),
                                  ),
                                ),
                              ],
                            ),

                        SizedBox(height: 30,),
                      ]),
                    )
                ),


              ),
              SizedBox(height: 20,),
              Text("Vibration Data",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
              SizedBox(height: 10,),
              Card(
                child:  AspectRatio(
                  aspectRatio: 1.70,
                  child: Padding(
                    padding: const EdgeInsets.only(
                      right: 18,
                      left: 12,
                      top: 24,
                      bottom: 12,
                    ),
                    // child: LineChart(
                    //   showAvg ? avgData() : mainData(),
                    // ),


                    child: ListView(
                      scrollDirection: Axis.horizontal, // Scroll horizontally
                      children: [
                        SizedBox(
                          width: data.length * 50.0, // Adjust the width based on your data
                          child: LineChart(
                            LineChartData(
                                gridData: FlGridData(
                                  show: true, // Show the grid
                                  drawHorizontalLine: true, // Show horizontal grid lines
                                  drawVerticalLine: true, // Show vertical grid lines
                                  horizontalInterval: (2 - 0) / 5, // Customize the horizontal grid interval
                                  verticalInterval: 1.0, // Customize the vertical grid interval
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: const Color(0xff37434d), // Customize the grid line color
                                      strokeWidth: 0.5, // Customize the grid line width
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: const Color(0xff37434d), // Customize the grid line color
                                      strokeWidth: 0.5, // Customize the grid line width
                                    );
                                  },
                                ),
                              titlesData: FlTitlesData(show: true),
                              borderData: FlBorderData(
                                show: true,
                                border: Border.all(color: const Color(0xff37434d), width: 1),
                              ),
                              minX: 0,
                              maxX: data.length.toDouble() - 1,
                              minY: 0,
                              maxY: 2,
                              lineBarsData: [
                                LineChartBarData(
                                  spots: data,
                                  isCurved: true,
                                  color: Colors.blue,
                                  dotData: FlDotData(show: false),
                                  belowBarData: BarAreaData(show: false),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),

                    //child: LineChart(
                      // LineChartData(
                      //   // Configure chart appearance and behavior here
                      //   gridData: FlGridData(show: false),
                      //   titlesData: FlTitlesData(show: false),
                      //   borderData: FlBorderData(
                      //     show: true,
                      //     border: Border.all(color: const Color(0xff37434d), width: 1),
                      //   ),
                      //   minX: 0,
                      //   maxX: 10, // Adjust as needed
                      //   minY: 0,
                      //   maxY: 10, // Adjust as needed
                      //   lineBarsData: [
                      //     LineChartBarData(
                      //       spots: data,
                      //       isCurved: true,
                      //       color: Colors.blue,
                      //       dotData: FlDotData(show: false),
                      //       belowBarData: BarAreaData(show: false),
                      //     ),
                      //   ],
                      // ),

                  //  LineChartData(
                  //   gridData: FlGridData(show: false),
                  //   titlesData: FlTitlesData(show: false),
                  //   borderData: FlBorderData(
                  //     show: true,
                  //     border: Border.all(color: const Color(0xff37434d), width: 1),
                  //   ),
                  //   minX: 0,
                  //   maxX: 10, // Adjust as needed
                  //   minY: 0,
                  //   maxY: 100, // Adjust as needed
                  //   lineBarsData: [
                  //     LineChartBarData(
                  //       spots: data,
                  //       isCurved: true,
                  //       color: Colors.blue,
                  //       dotData: FlDotData(show: false),
                  //       belowBarData: BarAreaData(show: false),
                  //     ),
                  //   ],
                  // )


                    //)
                  ),
                ),
              ),
              Card(
                child:  SfSparkLineChart.custom(
                  //Enable the trackball
                  trackball: SparkChartTrackball(
                      activationMode: SparkChartActivationMode.tap),
                  //Enable marker
                  marker: SparkChartMarker(
                      displayMode: SparkChartMarkerDisplayMode.all),
                  //Enable data label
                  labelDisplayMode: SparkChartLabelDisplayMode.all,
                  xValueMapper: (int index) => data1[index].year,
                  yValueMapper: (int index) => data1[index].sales,
                  dataCount: 5,
                ),
              )

            ],
          ),
        ),
      ),
    );
  }

  void onConnected() {
    print(
        'EXAMPLE::OnConnected client callback - Client connection was successful');
  }

  void onDisconnected() {
    print('EXAMPLE::OnDisconnected client callback - Client disconnection');
    if (client.connectionStatus!.disconnectionOrigin ==
        MqttDisconnectionOrigin.solicited) {
      print('EXAMPLE::OnDisconnected callback is solicited, this is correct');
    } else {
      print(
          'EXAMPLE::OnDisconnected callback is unsolicited or none, this is incorrect - exiting');
      exit(-1);
    }

  }

  void onSubscribed(String topic) {
    print('EXAMPLE::Subscription confirmed for topic $topic');
  }

  LineChartData avgData() {
    return LineChartData(
      lineTouchData: LineTouchData(enabled: false),
      gridData: FlGridData(
        show: true,
        drawHorizontalLine: true,
        verticalInterval: 1,
        horizontalInterval: 1,
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: Color(0xff37434d),
            strokeWidth: 1,
          );
        },
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: Color(0xff37434d),
            strokeWidth: 1,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 30,
            getTitlesWidget: bottomTitleWidgets,
            interval: 1,
          ),
        ),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            getTitlesWidget: leftTitleWidgets,
            reservedSize: 42,
            interval: 1,
          ),
        ),
        topTitles: AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
        rightTitles: AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
      ),
      borderData: FlBorderData(
        show: true,
        border: Border.all(color: const Color(0xff37434d)),
      ),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 6,
      lineBarsData: [
        LineChartBarData(
          spots: const [
            FlSpot(0, 3.44),
            FlSpot(2.6, 3.44),
            FlSpot(4.9, 3.44),
            FlSpot(6.8, 3.44),
            FlSpot(8, 3.44),
            FlSpot(9.5, 3.44),
            FlSpot(11, 3.44),
          ],
          isCurved: true,
          gradient: LinearGradient(
            colors: [
              ColorTween(begin: gradientColors[0], end: gradientColors[1])
                  .lerp(0.2)!,
              ColorTween(begin: gradientColors[0], end: gradientColors[1])
                  .lerp(0.2)!,
            ],
          ),
          barWidth: 5,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(
            show: true,
            gradient: LinearGradient(
              colors: [
                ColorTween(begin: gradientColors[0], end: gradientColors[1])
                    .lerp(0.2)!
                    .withOpacity(0.1),
                ColorTween(begin: gradientColors[0], end: gradientColors[1])
                    .lerp(0.2)!
                    .withOpacity(0.1),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget bottomTitleWidgets(double value, TitleMeta meta) {
    const style = TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 16,
    );
    Widget text;
    switch (value.toInt()) {
      case 2:
        text = const Text('MAR', style: style);
        break;
      case 5:
        text = const Text('JUN', style: style);
        break;
      case 8:
        text = const Text('SEP', style: style);
        break;
      default:
        text = const Text('', style: style);
        break;
    }

    return SideTitleWidget(
      axisSide: meta.axisSide,
      child: text,
    );
  }

  Widget leftTitleWidgets(double value, TitleMeta meta) {
    const style = TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 15,
    );
    String text;
    switch (value.toInt()) {
      case 1:
        text = '10K';
        break;
      case 3:
        text = '30k';
        break;
      case 5:
        text = '50k';
        break;
      default:
        return Container();
    }

    return Text(text, style: style, textAlign: TextAlign.left);
  }

  LineChartData mainData() {
    return LineChartData(
      gridData: FlGridData(
        show: true,
        drawVerticalLine: true,
        horizontalInterval: 1,
        verticalInterval: 1,
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: Colors.white10,
            strokeWidth: 1,
          );
        },
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: Colors.white10,
            strokeWidth: 1,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        rightTitles: AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
        topTitles: AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 30,
            interval: 1,
            getTitlesWidget: bottomTitleWidgets,
          ),
        ),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            interval: 1,
            getTitlesWidget: leftTitleWidgets,
            reservedSize: 42,
          ),
        ),
      ),
      borderData: FlBorderData(
        show: true,
        border: Border.all(color: const Color(0xff37434d)),
      ),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 6,
      lineBarsData: [
        LineChartBarData(
          spots: const [
            FlSpot(0, 3),
            FlSpot(2.6, 2),
            FlSpot(4.9, 5),
            FlSpot(6.8, 3.1),
            FlSpot(8, 4),
            FlSpot(9.5, 3),
            FlSpot(11, 4),
          ],
          isCurved: true,
          gradient: LinearGradient(
            colors: gradientColors,
          ),
          barWidth: 5,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(
            show: true,
            gradient: LinearGradient(
              colors: gradientColors
                  .map((color) => color.withOpacity(0.3))
                  .toList(),
            ),
          ),
        ),
      ],
    );
  }
}
