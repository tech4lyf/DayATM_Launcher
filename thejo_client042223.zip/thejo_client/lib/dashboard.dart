import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:thejo_client/home.dart';
import 'package:thejo_client/monitorScreen.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {

  List<DocumentSnapshot> items = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    FirebaseFirestore.instance.collection('thejo_blades').get().then((QuerySnapshot querySnapshot) {
      setState(() {
        items = querySnapshot.docs;
      });
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("List of Devices"),backgroundColor: Colors.orange,),
        body: Container(
          child:ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              // return ListTile(
              //   title: Text('Blade Name: ${items[index]['b_name']}'),
              //   subtitle: Text('Location: ${items[index]['b_loc']}'),
              //   onTap:(){
              //     Navigator.push(
              //       context,
              //       MaterialPageRoute(builder: (context) => HomePage()),
              //     );
              //   } ,
              //   // Add more fields as needed
              // );

              return InkWell(
                onTap: (){
                  Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => MonitorPage(bladeName: items[index]['b_name'],bladeLoc: items[index]['b_loc'],)),
                          );


                },
                child: Card(

                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.0), // Set the radius for the card
                  ),
                  child: Stack(
                    children: [
                      // Gradient background
                      Container(
                        height: 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12.0), // Set the same radius
                          gradient: LinearGradient(
                            colors: [Color.fromRGBO(194, 96, 137, 1), Color.fromRGBO(148, 96, 210, 1)], // Define your gradient colors
                            begin: Alignment.bottomRight,
                            end: Alignment.topLeft,
                          ),
                        ),
                      ),
                      // Content of the card
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child:
                        Row(
                          children: [
                            // Left half
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                  '${items[index]['b_name']}',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18.0,
                                    color: Colors.white,
                                  ),
                                ),
                                  Text(
                                    '${items[index]['b_loc']}',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18.0,
                                      color: Colors.white,
                                    ),
                                  ),
                        ]
                              ),
                            ),
                            // Right half
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Icon(Icons.favorite,
                                          color: items[index]['b_life']>60? Colors.green : items[index]['b_life']>40 && items[index]['b_life']<60 ?Colors.orange:Colors.red
                                      ),
                                      Padding(padding: EdgeInsets.only(left: 10)),
                                      Text(
                                    '${items[index]['b_life']}%',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 20.0,
                                      color: Colors.white,
                                    ),
                                ),
                              ]
                                  ),
                              ]
                              ),
                            ),
                          ],
                        )

                      ),
                    ],
                  ),
                ),
              );
            },
          ),

        ),
        floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.orange,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => CreateDevice()),
            );
          },
          child: Icon(Icons.add),
        ),

    );
  }
}

class HelloConvexAppBar extends StatefulWidget {

  @override
  State<HelloConvexAppBar> createState() => _HelloConvexAppBarState();
}

class _HelloConvexAppBarState extends State<HelloConvexAppBar> {



  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Thejo')),
      body: Center(
          child: TextButton(
            child: Text('Click to show full example'),
            onPressed: () => Navigator.of(context).pushNamed('/bar'),
          )),
      bottomNavigationBar: ConvexAppBar(
        style: TabStyle.fixed,
        items: [
          TabItem(icon: Icons.list),
          TabItem(icon: Icons.add),
          TabItem(icon: Icons.assessment),
        ],
        initialActiveIndex: 1,
        onTap: (int i) {
          print('click index=$i');
          switch(i)
              {
            case 1:
              Navigator.of(context).pushNamed('/create');
              break;
          }
        }
      ),
    );
  }
}


class CreateDevice extends StatefulWidget {
  @override
  _CreateDeviceState createState() => _CreateDeviceState();
}

class _CreateDeviceState extends State<CreateDevice> {
  TextEditingController _textFieldController1 = TextEditingController();
  TextEditingController _textFieldController2 = TextEditingController();
  TextEditingController _textFieldController3 = TextEditingController();
  TextEditingController _textFieldController4 = TextEditingController();
  TextEditingController _textFieldController5 = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('Create Device'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _textFieldController1,
              decoration: InputDecoration(labelText: 'Blade Name'),
            ),
            TextField(
              controller: _textFieldController2,
              decoration: InputDecoration(labelText: 'Blade Length'),
            ),
            TextField(
              controller: _textFieldController3,
              decoration: InputDecoration(labelText: 'Site Location'),
            ),
            TextField(
              controller: _textFieldController4,
              decoration: InputDecoration(labelText: 'Param-1'),
            ),
            TextField(
              controller: _textFieldController5,
              decoration: InputDecoration(labelText: 'Param-2'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // You can access the values entered in the textboxes using the controllers.
                String value1 = _textFieldController1.text;
                String value2 = _textFieldController2.text;
                String value3 = _textFieldController3.text;
                String value4 = _textFieldController4.text;
                String value5 = _textFieldController5.text;

                // Do something with the values, e.g., print them.
                print('Value 1: $value1');
                print('Value 2: $value2');
                print('Value 3: $value3');
                print('Value 4: $value4');
                print('Value 5: $value5');

                FirebaseFirestore.instance.collection('thejo_blades').add({
                  'b_name': value1,
                  'b_len': value2,
                  'b_loc': value3,
                  'b_life': 100,
                  'field4': value4,
                  'field5': value5,
                }).then((value) {
                  // Data added successfully
                  print('Data added to Firestore');
                  Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (_) => Dashboard()),
                          (Route route) => false);
                }).catchError((error) {
                  // Handle any errors
                  print('Error adding data to Firestore: $error');
                });
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
