import 'dart:convert';
import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:thejo_client/login.dart';

void main() async
{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(
      theme: ThemeData(
          primarySwatch: Colors.orange,
      ),

      debugShowCheckedModeBanner: false,
      home: LoginPage()));

}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  bool isSwitched = false;
  var textValue = 'Motor is OFF';



  double per=0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();


  }




  @override
  Widget build(BuildContext context) {




    return Scaffold(
      appBar: AppBar(),
      body: Container(

        child: Center(
          child: Column(
            children: [
              ElevatedButton(onPressed: (){

              }, child: Text("Connect")),

              Text("${per} Percentage",

                style: TextStyle(

                  fontSize: 20,

                ),
              ),
              SizedBox(height: 50,),
      //
      //     Switch(
      //       onChanged: toggleSwitch,
      //       value: isSwitched,
      //       activeColor: Colors.blue,
      //       activeTrackColor: Colors.yellow,
      //       inactiveThumbColor: Colors.redAccent,
      //       inactiveTrackColor: Colors.orange,
      //     ),
      // Text('$textValue', style: TextStyle(fontSize: 20),)


      ],
          ),
        ),

      ),
    );
  }


  void toggleSwitch(bool value) {

    if(isSwitched == false)
    {
      setState(() {
        isSwitched = true;
        textValue = 'Motor is ON';
      });
      print('Motor is ON');
      final builder = MqttClientPayloadBuilder();
      builder.addString('1');
      // client.publishMessage("paradigm", MqttQos.exactlyOnce, builder.payload!);
    }
    else
    {
      setState(() {
        isSwitched = false;
        textValue = 'Motor is OFF';
      });
      print('Motor is OFF');
      final builder = MqttClientPayloadBuilder();
      builder.addString('0');
      // client.publishMessage("paradigm", MqttQos.exactlyOnce, builder.payload!);
    }
  }

}
