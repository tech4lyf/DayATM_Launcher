import 'dart:convert';
import 'dart:io';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:thejo_client/lineGraph.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MQTT Line Graph',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<FlSpot> dataPoints = []; // Store the data for the line graph
  final client = MqttServerClient('mqtt-dashboard.com', '');

  @override
  void initState() {
    super.initState();

    initMQTT();
  }

  void initMQTT()
  async {
    client.onDisconnected = onDisconnected;
    client.onConnected = onConnected;
    client.onSubscribed = onSubscribed;
    final connMess = MqttConnectMessage()
        .withClientIdentifier('Mqtt_MyClientUniqueId')
        .withWillTopic('willtopic') // If you set this you must set a will message
        .withWillMessage('My Will message')
        .startClean() // Non persistent session for testing
        .withWillQos(MqttQos.atLeastOnce);
    print('EXAMPLE::Mosquitto client connecting....');
    client.connectionMessage = connMess;

    try {
      await client.connect();
      client.subscribe("t4l", MqttQos.atMostOnce);
    } on NoConnectionException catch (e) {
      // Raised by the client when connection fails.
      print('EXAMPLE::client exception - $e');
      client.disconnect();
    } on SocketException catch (e) {
      // Raised by the socket layer
      print('EXAMPLE::socket exception - $e');
      client.disconnect();
    }


  }


  void onConnected() {
    print('Connected to MQTT broker');
  }

  void onDisconnected() {
    print('Disconnected from MQTT broker');
  }

  void onSubscribeFail(String topic) {
    print('Failed to subscribe to topic: $topic');
  }

  void onSubscribed(String topic) {
    print('Subscribed to topic: $topic');
  }

  void onUnsubscribed(String topic) {
    print('Unsubscribed from topic: $topic');
  }

  @override
  void dispose() {
    client?.disconnect();
    super.dispose();
  }

  double i=0;
  @override
  Widget build(BuildContext context) {

    client.updates!.listen((List<MqttReceivedMessage<MqttMessage?>>? c) {
      final recMess = c![0].payload as MqttPublishMessage;
      final pt =
      MqttPublishPayload.bytesToStringAsString(recMess.payload.message);


      print(
          'EXAMPLE::Change notification:: topic is <${c[0].topic}>, payload is <-- $pt -->');
      print('');

      final Map<String, dynamic> jsonData = jsonDecode(pt);
      final double x = double.parse(jsonData['Roll'].toString());
      final double y = double.parse(jsonData['Pitch'].toString());

      final now = DateTime.now();
      final formatter = DateFormat('HH:mm:ss');




      setState(() {
        dataPoints.add(FlSpot(i, x));
      });

      i=i+1;


    });
    return Scaffold(
      appBar: AppBar(
        title: Text('MQTT Line Graph'),
      ),
      body: Center(
        // child: LineGraphWidget(dataPoints: dataPoints),
      ),
    );
  }
}
