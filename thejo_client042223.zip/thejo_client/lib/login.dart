import 'package:flutter/material.dart';
import 'package:thejo_client/dashboard.dart';
import 'package:thejo_client/home.dart';
import 'package:thejo_client/toast.dart';




class LoginPage extends StatelessWidget {

  var userCon=TextEditingController();
  var passCon=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // Your company logo here
            Image.asset(
              'assets/images/thejo.png', // Replace with your logo file path
              width: 150,
            ),
            SizedBox(height: 20),
            Text(
              'Please Login to Continue',
              style: TextStyle(
                color: Color(0xFFF78F1E),
                fontSize: 24,
              ),
            ),
            SizedBox(height: 20),
            // Add your login form here
            // For simplicity, you can use TextFormField or any other form elements

            SizedBox(height: 20),
            // Username TextField
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              child: TextFormField(
                controller: userCon,
                decoration: InputDecoration(
                  labelText: 'Username',
                  fillColor: Colors.white,
                  filled: true,
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            SizedBox(height: 20),
            // Password TextField
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              child: TextFormField(
                controller: passCon,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                  fillColor: Colors.white,
                  filled: true,
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            SizedBox(height: 20),
            SizedBox(
              width: 200,
              child: ElevatedButton(

                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    backgroundColor: Color(0xFFF78F1E),
                ),
                onPressed: () {
                  // Implement your login logic here
                  if(userCon.text=="user" && passCon.text=="1234") {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Dashboard()),
                    );
                  }
                  else
                    {
                      toast("Invalid User");
                    }
                },
                child: Text('Login',style: TextStyle(fontSize: 18),),
              ),
            )
          ],
        ),
      ),
    );
  }
}
