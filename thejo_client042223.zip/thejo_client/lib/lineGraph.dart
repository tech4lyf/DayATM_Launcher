import 'dart:async';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class EcgGraph extends StatefulWidget {
  @override
  _EcgGraphState createState() => _EcgGraphState();
}

class _EcgGraphState extends State<EcgGraph> {
  final List<FlSpot> ecgData = List.generate(1200, (index) => FlSpot(index.toDouble(), index.toDouble()));
  int currentIndex = 0;
  Timer? ecgTimer;

  @override
  void initState() {
    super.initState();

    ecgTimer = Timer.periodic(Duration(milliseconds: 100), (timer) {
      setState(() {
        if (currentIndex < 99) {
          currentIndex++;
        } else {
          currentIndex = 0;
        }
        ecgData[currentIndex] = FlSpot(currentIndex.toDouble(), generateRandomEcgValue());
      });
    });
  }

  double generateRandomEcgValue() {
    // Simulate ECG data here (replace with actual data source)
    return (currentIndex % 2 == 0) ? 1.0 : -1.0;
  }

  @override
  void dispose() {
    ecgTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LineChart(
      LineChartData(
        gridData: FlGridData(show: false),
        titlesData: FlTitlesData(show: false),
        borderData: FlBorderData(
          show: true,
          border: Border(
            bottom: BorderSide(color: Colors.blue, width: 2),
            left: BorderSide(color: Colors.blue, width: 2),
          ),
        ),
        minX: 0,
        maxX: 100,
        minY: -2,
        maxY: 2,
        lineBarsData: [
          LineChartBarData(
            isCurved: true,
            color: Colors.blue,
            belowBarData: BarAreaData(show: false),
            spots: ecgData,
          ),
        ],
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(
        title: Text('ECG Graph Example'),
      ),
      body: EcgGraph(),
    ),
  ));
}
