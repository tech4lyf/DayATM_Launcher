import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CustomAlertDialog extends StatefulWidget {
  @override
  _CustomAlertDialogState createState() => _CustomAlertDialogState();
}

class _CustomAlertDialogState extends State<CustomAlertDialog> {
  String dropdownValue = 'CCW';
  TextEditingController textController = TextEditingController();
  TextEditingController textControllerVib = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Settings'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextField(
            controller: textController,
            decoration: InputDecoration(labelText: 'Max Temperature'),
          ),
          TextField(
            controller: textControllerVib,
            decoration: InputDecoration(labelText: 'Max Vibration'),
          ),
          SizedBox(height: 16),
          Text("Blade Orientation"),
          DropdownButton<String>(
            value: dropdownValue,
            onChanged: (newVal){
              setState(() {
                dropdownValue=newVal!;
              });

            },
            // onChanged: (String newValue) {
            //   setState(() {
            //     dropdownValue = newValue;
            //   });
            // },
            items: <String>['CCW', 'CW']
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
          ),
        ],
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop(); // Close the dialog
          },
          child: Text('Cancel'),
        ),
        TextButton(
          onPressed: () async{
            // Perform an action with the entered text and selected dropdown value
            print('Entered text: ${textController.text}');
            print('Selected dropdown value: $dropdownValue');
            SharedPreferences prefs = await SharedPreferences.getInstance();
            await prefs.setDouble('maxTemp', double.parse(textController.text.toString()));
            await prefs.setDouble('maxVib', double.parse(textControllerVib.text.toString()));
            await prefs.setString('bType', dropdownValue);

            Navigator.of(context).pop(); // Close the dialog



          },
          child: Text('OK'),
        ),
      ],
    );
  }
}