package com.tech4lyf.thejo_client

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
